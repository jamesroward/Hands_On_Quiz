<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Models\Song;
use App\Models\Artist;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// CRUD USING ELOQUENT

// CREATE
Route::post('song/create', function(Request $request) {
    $residents = new song;
    //$course->name = $request->name;
    //$course->is_draft = $request->is_draft;
    $residents->fill($request->all());
    $residents->save();

    return $songs;
});
// READ
Route::get('songs', function() {
    $songs = Song::with('artist')->get();
    return $songs;
});

// UPDATE
Route::put('/song/{id}', function(Request $request, $id){
$songs = songs::find($id);
$songs->title = 'Anti-Hero';
$songs->save();
return $songs;

});
//DELETE
Route::delete('/song/{id}', function(Request $request, $id){
    $songs = Resident::find($id);
    $songs->delete();
    return $songs;
    
    });



