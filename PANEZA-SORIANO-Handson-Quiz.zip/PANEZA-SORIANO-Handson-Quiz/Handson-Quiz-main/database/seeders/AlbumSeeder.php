<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;


class StaffSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('albums')->insert([
            [
                'title' => 'Midnights',
                'dateadded' => 'October 21, 2022',
            ],
            [
                'title' => 'Folklore',
                'dateadded' => 'July 24, 2020',
            ],            
            [
                'title' => 'Evermore',
                'dateadded' => 'December 11, 2020',
            ],
            ]);   
    }
}
