<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ResidentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('songs')->insert([
            [
                'title' => 'Anti-Hero',
                'dateadded' => 'October 21, 2022',
                'releasedate' => 'October 21, 2022',
                'runtime' => '3:20',
            ],
            [
                'title' => 'Cardigan',
                'dateadded' => 'July 24, 2020',
                'releasedate' => 'July 24, 2020',
                'runtime' => '3:59',
            ],
            [
                'title' => 'Willow',
                'dateadded' => 'December 11, 2020',
                'releasedate' => 'December 11, 2020',
                'runtime' => '3:34',
            ]
            ]); 
    }
}
